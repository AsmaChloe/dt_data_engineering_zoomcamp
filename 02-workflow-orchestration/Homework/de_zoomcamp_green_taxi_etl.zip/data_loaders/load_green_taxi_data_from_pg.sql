-- Docs: https://docs.mage.ai/guides/sql-blocks
select distinct vendor_id from mage.green_taxi