import re 

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

def format_column_name(column_name) :

    if('_' not in column_name) :
        column_name_list = re.findall('[A-Z]+[^A-Z]*', column_name)
        if len(column_name_list) == 0 :
            return str.lower(column_name)
        column_name_list = [str.lower(word) for word in column_name_list]
        return '_'.join(column_name_list)
    
    return str.lower(column_name)

@transformer
def transform(data, *args, **kwargs):
    """
    Template code for a transformer block.

    Add more parameters to this function if this block has multiple parent blocks.
    There should be one parameter for each output variable from each parent block.

    Args:
        data: The output from the upstream parent block
        args: The output from any additional upstream blocks (if applicable)

    Returns:
        Anything (e.g. data frame, dictionary, array, int, str, etc.)
    """
    # Specify your transformation logic here

    #Remove where passenger count == 0 or trip distance == 0
    data = data[ (data['passenger_count'] > 0) & (data['trip_distance']>0) ]

    #Create new column lpep_pickup_date
    data['lpep_pickup_date'] = data['lpep_pickup_datetime'].map(lambda x : x.date())

    #Format column names
    data.columns = data.columns.map(lambda x : format_column_name(x) )

    return data


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'


@test
def test_column_vendor_id_exists(output, *args) -> None:
    """
    Test if column vendor_id exists in dataset
    """
    assert 'vendor_id' in output.columns, "The column 'vendor_id' has not been found"


@test
def test_passenger_count(output, *args) -> None:
    """
    Test if passenger_count is greater than 0
    """
    assert len(output[ output['passenger_count'] == 0 ]) == 0, "Some rides have passenger counts to 0"

@test
def test_trip_distance(output, *args) -> None:
    """
    Test if trip_distance is greater than 0
    """
    assert len(output[ output['trip_distance'] == 0 ]) == 0, "Some rides have a trip distance to 0"